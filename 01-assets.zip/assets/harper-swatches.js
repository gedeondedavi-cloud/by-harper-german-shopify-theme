(function () {
  var HEX = {
    black: '#1A1A1A', noir: '#1A1A1A',
    white: '#FFFFFF', blanc: '#FFFFFF',
    grey: '#9A968C', gris: '#9A968C',
    blue: '#2E3D52', bleu: '#2E3D52',
    red: '#8E3B3B', rouge: '#8E3B3B',
    beige: '#C9C4BA',
    brown: '#6B5545', brun: '#6B5545',
    pink: '#D9A3AE', rose: '#D9A3AE'
  };

  var MAX = 4;

  function swatchStyle(card) {
    var g = (card.dataset.group || '').toLowerCase();
    if (HEX[g]) return 'background-color:' + HEX[g];
    if (card.dataset.swatch) {
      return 'background-image:url(' + card.dataset.swatch + ');background-size:cover;background-position:center';
    }
    return 'background-color:#C9C4BA';
  }

  function group(scope) {
    var cards = scope.querySelectorAll('[data-harper-card]');
    if (!cards.length) return;

    var families = {};
    cards.forEach(function (c) {
      var k = c.dataset.style;
      if (!k) return;
      (families[k] = families[k] || []).push(c);
    });

    Object.keys(families).forEach(function (k) {
      var sibs = families[k];
      if (sibs.length < 2) return;

      var lead = sibs[0];
      var box = lead.querySelector('[data-harper-swatches]');
      if (!box) return;

      sibs.slice(1).forEach(function (c) { c.hidden = true; });

      box.innerHTML = '';
      sibs.slice(0, MAX).forEach(function (c, i) {
        var a = document.createElement('a');
        a.href = c.dataset.url;
        a.setAttribute('style', swatchStyle(c));
        a.setAttribute('aria-label', c.dataset.color || 'Coloris');
        if (i === 0) a.setAttribute('aria-current', 'true');
        box.appendChild(a);
      });

      if (sibs.length > MAX) {
        var more = document.createElement('span');
        more.className = 'h-sw__more';
        more.textContent = '+' + (sibs.length - MAX);
        box.appendChild(more);
      }
    });
  }

  function run() { group(document); }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', run);
  } else {
    run();
  }

  document.addEventListener('shopify:section:load', function (e) { group(e.target); });
})();
